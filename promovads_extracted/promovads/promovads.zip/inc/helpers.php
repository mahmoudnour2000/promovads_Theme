<?php
/**
 * Theme Helper Functions
 *
 * @package PromovaDS_News
 */

defined( 'ABSPATH' ) || exit;

/**
 * Get post thumbnail with lazy loading.
 */
function promovads_thumbnail( int $post_id = 0, string $size = 'promovads-card', string $class = '' ): string {
	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	if ( has_post_thumbnail( $post_id ) ) {
		$html = get_the_post_thumbnail(
			$post_id,
			$size,
			array(
				'class'   => 'pds-img-cover ' . esc_attr( $class ),
				'loading' => 'lazy',
				'decoding' => 'async',
			)
		);
		return $html;
	}

	$placeholder = PROMOVADS_URI . '/assets/images/placeholder.jpg';
	return sprintf(
		'<img src="%s" alt="%s" class="pds-img-cover %s" loading="lazy" decoding="async">',
		esc_url( $placeholder ),
		esc_attr( get_the_title( $post_id ) ),
		esc_attr( $class )
	);
}

/**
 * Get category badge HTML.
 */
function promovads_category_badge( int $post_id = 0, bool $link = true ): string {
	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$cats = get_the_category( $post_id );
	if ( empty( $cats ) ) {
		return '';
	}

	$cat   = $cats[0];
	$color = get_term_meta( $cat->term_id, 'pds_color', true );
	$style = $color ? ' style="background-color:' . esc_attr( $color ) . '"' : '';

	if ( $link ) {
		return sprintf(
			'<a href="%s" class="pds-card__cat"%s>%s</a>',
			esc_url( get_category_link( $cat->term_id ) ),
			$style,
			esc_html( $cat->name )
		);
	}

	return sprintf(
		'<span class="pds-card__cat"%s>%s</span>',
		$style,
		esc_html( $cat->name )
	);
}

/**
 * Get reading time estimate.
 */
function promovads_reading_time( int $post_id = 0 ): string {
	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$content    = get_post_field( 'post_content', $post_id );
	$word_count = promovads_count_words( $content );
	$minutes    = max( 1, (int) ceil( $word_count / 200 ) );

	return sprintf(
		/* translators: %d: number of minutes */
		_n( '%d دقيقة قراءة', '%d دقائق قراءة', $minutes, 'promovads' ),
		$minutes
	);
}

/**
 * Count words in mixed Arabic/Latin content.
 */
function promovads_count_words( string $text ): int {
	$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $text ) ) );
	if ( '' === $text ) {
		return 0;
	}
	$parts = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
	return is_array( $parts ) ? count( $parts ) : 0;
}

/**
 * Author display name — use profile name, or account email if empty.
 */
function promovads_author_display_name( int $author_id = 0 ): string {
	if ( ! $author_id ) {
		$author_id = (int) get_the_author_meta( 'ID' );
	}

	$candidates = array(
		get_the_author_meta( 'display_name', $author_id ),
		get_the_author_meta( 'nickname', $author_id ),
		trim( get_the_author_meta( 'first_name', $author_id ) . ' ' . get_the_author_meta( 'last_name', $author_id ) ),
	);

	foreach ( $candidates as $name ) {
		$name = trim( (string) $name );
		if ( $name && ! str_contains( $name, '@' ) ) {
			return $name;
		}
	}

	$email = sanitize_email( (string) get_the_author_meta( 'user_email', $author_id ) );
	if ( $email ) {
		return $email;
	}

	return __( 'محرر', 'promovads' );
}

/**
 * Get post views count.
 */
function promovads_get_views( int $post_id = 0 ): int {
	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}
	return (int) get_post_meta( $post_id, 'pds_views', true );
}

/**
 * Increment post views.
 */
function promovads_increment_views( int $post_id ): void {
	$views = promovads_get_views( $post_id );
	update_post_meta( $post_id, 'pds_views', $views + 1 );
}

/**
 * Format large numbers for display.
 */
function promovads_format_number( int $number ): string {
	if ( $number >= 1000000 ) {
		return round( $number / 1000000, 1 ) . 'M';
	}
	if ( $number >= 1000 ) {
		return round( $number / 1000, 1 ) . 'K';
	}
	return (string) $number;
}

/**
 * Get human-friendly time ago.
 */
function promovads_time_ago( int $post_id = 0 ): string {
	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$timestamp = get_post_timestamp( $post_id );
	$diff      = time() - $timestamp;

	if ( $diff < 3600 ) {
		$mins = (int) floor( $diff / 60 );
		return sprintf( esc_html__( '%d min ago', 'promovads' ), max( 1, $mins ) );
	}
	if ( $diff < 86400 ) {
		$hours = (int) floor( $diff / 3600 );
		return sprintf( esc_html__( '%dh ago', 'promovads' ), $hours );
	}
	if ( $diff < 604800 ) {
		$days = (int) floor( $diff / 86400 );
		return sprintf( esc_html__( '%dd ago', 'promovads' ), $days );
	}

	return get_the_date( '', $post_id );
}

/**
 * Get trending posts (views first, then recent posts as fallback).
 */
function promovads_get_trending( int $count = 5, array $args = array() ): WP_Query {
	$exclude = array_map( 'absint', (array) ( $args['post__not_in'] ?? array() ) );
	unset( $args['post__not_in'] );

	$pool_size = max( $count * 4, 20 );
	$query     = new WP_Query(
		array_merge(
			array(
				'posts_per_page'      => $pool_size,
				'ignore_sticky_posts' => true,
				'post_status'         => 'publish',
				'post__not_in'        => $exclude,
				'orderby'             => 'date',
				'order'               => 'DESC',
			),
			$args
		)
	);

	$posts = $query->posts;
	usort(
		$posts,
		static function ( WP_Post $a, WP_Post $b ): int {
			$views_a = (int) get_post_meta( $a->ID, 'pds_views', true );
			$views_b = (int) get_post_meta( $b->ID, 'pds_views', true );

			if ( $views_a !== $views_b ) {
				return $views_b <=> $views_a;
			}

			return strtotime( $b->post_date ) <=> strtotime( $a->post_date );
		}
	);

	$posts               = array_slice( $posts, 0, $count );
	$query->posts        = $posts;
	$query->post_count   = count( $posts );
	$query->found_posts  = count( $posts );
	$query->max_num_pages = 1;

	return $query;
}

/**
 * Adjacent post data for single navigation.
 *
 * @return array{title:string,url:string}|null
 */
function promovads_get_adjacent_post_data( string $direction = 'prev' ): ?array {
	$in_same_term = true;
	$post         = 'next' === $direction
		? get_next_post( $in_same_term, '', 'category' )
		: get_previous_post( $in_same_term, '', 'category' );

	if ( ! $post instanceof WP_Post ) {
		$post = 'next' === $direction
			? get_next_post( false )
			: get_previous_post( false );
	}

	if ( ! $post instanceof WP_Post ) {
		return null;
	}

	return array(
		'title' => get_the_title( $post ),
		'url'   => get_permalink( $post ),
	);
}

/**
 * Get posts for a specific demo/section.
 */
function promovads_get_posts( array $args = array() ): WP_Query {
	$default = array(
		'posts_per_page'      => 6,
		'ignore_sticky_posts' => true,
		'post_status'         => 'publish',
	);
	return new WP_Query( array_merge( $default, $args ) );
}

/**
 * Get author social links.
 */
function promovads_author_social( int $user_id = 0 ): array {
	if ( ! $user_id ) {
		$user_id = get_the_author_meta( 'ID' );
	}

	$networks = array( 'twitter', 'facebook', 'instagram', 'linkedin', 'youtube', 'website' );
	$links    = array();

	foreach ( $networks as $net ) {
		$val = get_user_meta( $user_id, 'pds_social_' . $net, true );
		if ( $val ) {
			$links[ $net ] = esc_url( $val );
		}
	}

	return $links;
}

/**
 * Get review score stars HTML.
 */
function promovads_review_stars( float $score, float $max = 10 ): string {
	$percent = ( $score / $max ) * 100;
	$stars   = array();

	for ( $i = 1; $i <= 5; $i++ ) {
		$fill = min( 100, max( 0, ( $percent - ( ( $i - 1 ) * 20 ) ) * 5 ) );
		if ( $fill >= 100 ) {
			$stars[] = '<i class="fas fa-star pds-star--full"></i>';
		} elseif ( $fill >= 50 ) {
			$stars[] = '<i class="fas fa-star-half-alt pds-star--half"></i>';
		} else {
			$stars[] = '<i class="far fa-star pds-star--empty"></i>';
		}
	}

	return sprintf(
		'<span class="pds-stars" aria-label="%s/10">%s</span>',
		esc_attr( $score ),
		implode( '', $stars )
	);
}

/**
 * Truncate text safely.
 */
function promovads_truncate( string $text, int $length = 120, string $suffix = '...' ): string {
	$text = wp_strip_all_tags( $text );
	if ( mb_strlen( $text ) <= $length ) {
		return $text;
	}
	return mb_substr( $text, 0, $length ) . $suffix;
}

/**
 * Get post share URLs.
 */
function promovads_share_urls( int $post_id = 0 ): array {
	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$url   = rawurlencode( get_permalink( $post_id ) );
	$title = rawurlencode( get_the_title( $post_id ) );

	return array(
		'facebook'  => 'https://www.facebook.com/sharer/sharer.php?u=' . $url,
		'twitter'   => 'https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title,
		'whatsapp'  => 'https://wa.me/?text=' . $title . '%20' . $url,
		'linkedin'  => 'https://www.linkedin.com/shareArticle?mini=true&url=' . $url . '&title=' . $title,
		'telegram'  => 'https://t.me/share/url?url=' . $url . '&text=' . $title,
		'email'     => 'mailto:?subject=' . $title . '&body=' . $url,
	);
}

/**
 * Breadcrumb trail.
 */
function promovads_breadcrumb(): void {
	$separator = '<li class="pds-bc__sep" aria-hidden="true"><span>›</span></li>';
	$items     = array();

	$items[] = sprintf(
		'<li class="pds-bc__item"><a href="%s">%s</a></li>',
		esc_url( home_url( '/' ) ),
		esc_html( promovads_active_demo() ? __( 'الرئيسية', 'promovads' ) : __( 'Home', 'promovads' ) )
	);

	if ( is_category() ) {
		$items[] = sprintf( '<li class="pds-bc__item">%s</li>', esc_html( single_cat_title( '', false ) ) );
	} elseif ( is_single() ) {
		$cats = get_the_category();
		if ( $cats ) {
			$items[] = sprintf(
				'<li class="pds-bc__item"><a href="%s">%s</a></li>',
				esc_url( get_category_link( $cats[0]->term_id ) ),
				esc_html( $cats[0]->name )
			);
		}
		$items[] = sprintf( '<li class="pds-bc__item" aria-current="page">%s</li>', esc_html( get_the_title() ) );
	} elseif ( is_page() ) {
		if ( wp_get_post_parent_id( get_the_ID() ) ) {
			$parent  = get_post( wp_get_post_parent_id( get_the_ID() ) );
			$items[] = sprintf(
				'<li class="pds-bc__item"><a href="%s">%s</a></li>',
				esc_url( get_permalink( $parent ) ),
				esc_html( get_the_title( $parent ) )
			);
		}
		$items[] = sprintf( '<li class="pds-bc__item" aria-current="page">%s</li>', esc_html( get_the_title() ) );
	} elseif ( is_search() ) {
		$items[] = sprintf(
			'<li class="pds-bc__item">%s</li>',
			sprintf( esc_html__( 'Search: %s', 'promovads' ), esc_html( get_search_query() ) )
		);
	} elseif ( is_404() ) {
		$items[] = '<li class="pds-bc__item">404</li>';
	} elseif ( is_tag() ) {
		$items[] = sprintf( '<li class="pds-bc__item">%s</li>', esc_html( single_tag_title( '', false ) ) );
	}

	printf(
		'<nav class="pds-breadcrumb" aria-label="%s"><ol class="pds-bc__list">%s</ol></nav>',
		esc_attr__( 'Breadcrumb', 'promovads' ),
		implode( $separator, $items )
	);
}

/**
 * Return placeholder image URL for the given size.
 */
function promovads_placeholder_url( string $size = 'promovads-card' ): string {
	return esc_url( PROMOVADS_URI . '/assets/images/placeholder.jpg' );
}

/**
 * Get active demo name.
 */
function promovads_active_demo(): string {
	return sanitize_key( get_theme_mod( 'promovads_active_demo', '' ) );
}
